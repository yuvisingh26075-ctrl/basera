package com.basera;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

@RestController
@RequestMapping("/api")
public class ApiController {
    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");
    private final JdbcTemplate jdbc;
    private final ObjectMapper om;
    private final AuthService auth;
    private final TransactionTemplate tx;
    private final BCryptPasswordEncoder enc = new BCryptPasswordEncoder(12);
    private final SecureRandom rnd = new SecureRandom();
    private final Object bookingLock = new Object();   // one server instance: serialises booking checks

    public ApiController(JdbcTemplate jdbc, ObjectMapper om, AuthService auth, PlatformTransactionManager tm) {
        this.jdbc = jdbc; this.om = om; this.auth = auth; this.tx = new TransactionTemplate(tm);
    }

    /* ---------- helpers ---------- */
    private static String str(Map<String, Object> b, String k) {
        Object v = b == null ? null : b.get(k);
        return v == null ? "" : String.valueOf(v);
    }
    private static Double num(String s) { try { return s == null ? null : Double.valueOf(s); } catch (Exception e) { return null; } }
    private long uid(String header) { return Long.parseLong(auth.verify(header).getSubject()); }
    private Map<String, Object> session(long id, String name, String email) {
        return Map.of("token", auth.sign(id, name, email), "user", Map.of("name", name, "email", email));
    }
    private Map<String, Object> ok() { return Map.of("ok", true); }

    /* ---------- auth ---------- */
    @PostMapping("/auth/signup") @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> signup(@RequestBody Map<String, Object> b, HttpServletRequest req) {
        auth.limit(req.getRemoteAddr());
        String name = str(b, "name").trim(), email = str(b, "email").trim().toLowerCase(), pw = str(b, "password");
        if (name.length() < 2) throw new ApiException(400, "Enter your full name.");
        if (!email.matches("^\\S+@\\S+\\.\\S+$")) throw new ApiException(400, "Enter a valid email address.");
        if (pw.length() < 8) throw new ApiException(400, "Use at least 8 characters for your password.");
        try {
            jdbc.update("INSERT INTO users(name,email,pass_hash) VALUES(?,?,?)", name, email, enc.encode(pw));
        } catch (DataAccessException e) {
            throw new ApiException(409, "This email already has an account.");
        }
        Long id = jdbc.queryForObject("SELECT id FROM users WHERE email=?", Long.class, email);
        return session(id, name, email);
    }

    @PostMapping("/auth/login")
    public Map<String, Object> login(@RequestBody Map<String, Object> b, HttpServletRequest req) {
        auth.limit(req.getRemoteAddr());
        String email = str(b, "email").trim().toLowerCase();
        var rows = jdbc.queryForList("SELECT id,name,pass_hash FROM users WHERE email=?", email);
        if (rows.isEmpty() || !enc.matches(str(b, "password"), (String) rows.get(0).get("pass_hash")))
            throw new ApiException(401, "Email or password is incorrect.");
        var u = rows.get(0);
        return session(((Number) u.get("id")).longValue(), (String) u.get("name"), email);
    }

    @GetMapping("/me")
    public Map<String, Object> me(@RequestHeader(value = "Authorization", required = false) String h) {
        var c = auth.verify(h);
        return Map.of("name", c.get("name", String.class), "email", c.get("email", String.class));
    }

    /* ---------- hotels ---------- */
    private Map<String, Object> hotelOut(Map<String, Object> r) {
        Map<String, Object> m = new LinkedHashMap<>(r);
        try { m.put("amenities", om.readValue((String) r.get("amenities"), List.class)); }
        catch (Exception e) { m.put("amenities", List.of()); }
        return m;
    }
    private Map<String, Object> hotelRow(long id) {
        var r = jdbc.queryForList("SELECT * FROM hotels WHERE id=?", id);
        if (r.isEmpty()) throw new ApiException(404, "Stay not found.");
        return r.get(0);
    }

    @GetMapping("/hotels")
    public List<Map<String, Object>> hotels(@RequestParam Map<String, String> p) {
        List<String> w = new ArrayList<>(); List<Object> a = new ArrayList<>();
        String q = p.get("q");
        if (q != null && !q.isBlank()) { w.add("(name LIKE ? OR city LIKE ?)"); a.add("%" + q + "%"); a.add("%" + q + "%"); }
        String t = p.get("type");
        if (t != null && !t.isBlank() && !t.equals("All")) { w.add("type=?"); a.add(t); }
        Double mp = num(p.get("maxPrice")); if (mp != null) { w.add("price<=?"); a.add(mp); }
        Double mr = num(p.get("minRating")); if (mr != null) { w.add("rating>=?"); a.add(mr); }
        String order = switch (String.valueOf(p.get("sort"))) {
            case "pa" -> "price ASC"; case "pd" -> "price DESC"; case "rt" -> "rating DESC"; default -> "reviews DESC"; };
        String sql = "SELECT * FROM hotels" + (w.isEmpty() ? "" : " WHERE " + String.join(" AND ", w)) + " ORDER BY " + order;
        return jdbc.queryForList(sql, a.toArray()).stream().map(this::hotelOut).toList();
    }

    @GetMapping("/hotels/{id}")
    public Map<String, Object> hotel(@PathVariable long id) { return hotelOut(hotelRow(id)); }

    /* ---------- availability and pricing ---------- */
    private record Stay(LocalDate ci, LocalDate co, int guests) {}

    private Stay stay(String ci, String co, String g) {
        LocalDate a, b;
        try { a = LocalDate.parse(ci); b = LocalDate.parse(co); }
        catch (Exception e) { throw new ApiException(400, "Choose valid dates."); }
        if (a.isBefore(LocalDate.now(IST))) throw new ApiException(400, "Check-in cannot be in the past.");
        long n = ChronoUnit.DAYS.between(a, b);
        if (n < 1 || n > 30) throw new ApiException(400, "Stay must be 1 to 30 nights.");
        int guests;
        try { guests = Integer.parseInt(g); } catch (Exception e) { guests = 0; }
        if (guests < 1 || guests > 8) throw new ApiException(400, "Guests must be between 1 and 8.");
        return new Stay(a, b, guests);
    }

    private Map<String, Object> price(Map<String, Object> h, Stay s) {
        long n = ChronoUnit.DAYS.between(s.ci(), s.co());
        int rooms = (s.guests() + 2) / 3;                      // up to 3 guests per room
        long base = ((Number) h.get("price")).longValue() * n * rooms;
        long tax = Math.round(base * 0.12), fee = Math.round(base * 0.05);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("nights", n); m.put("rooms", rooms); m.put("base", base);
        m.put("tax", tax); m.put("fee", fee); m.put("total", base + tax + fee);
        return m;
    }

    /** Rooms free on every night of the stay. */
    private int roomsLeft(long hotelId, Stay s) {
        int total = ((Number) hotelRow(hotelId).get("rooms")).intValue(), min = total;
        for (LocalDate d = s.ci(); d.isBefore(s.co()); d = d.plusDays(1)) {
            Integer used = jdbc.queryForObject(
                "SELECT COALESCE(SUM(rooms),0) FROM bookings WHERE hotel_id=? AND status='confirmed' AND check_in<=? AND check_out>?",
                Integer.class, hotelId, d.toString(), d.toString());
            min = Math.min(min, total - (used == null ? 0 : used));
        }
        return Math.max(0, min);
    }

    @GetMapping("/hotels/{id}/quote")
    public Map<String, Object> quote(@PathVariable long id, @RequestParam Map<String, String> p) {
        var h = hotelRow(id);
        Stay s = stay(p.get("checkIn"), p.get("checkOut"), p.get("guests"));
        Map<String, Object> q = price(h, s);
        q.put("available", roomsLeft(id, s) >= ((Number) q.get("rooms")).intValue());
        return q;
    }

    /* ---------- bookings ---------- */
    @PostMapping("/bookings") @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> book(@RequestHeader(value = "Authorization", required = false) String ah,
                                    @RequestBody Map<String, Object> b) {
        long user = uid(ah), hid;
        try { hid = Long.parseLong(str(b, "hotelId")); } catch (Exception e) { throw new ApiException(404, "Stay not found."); }
        var h = hotelRow(hid);
        Stay s = stay(str(b, "checkIn"), str(b, "checkOut"), str(b, "guests"));
        Map<String, Object> q = price(h, s);
        int rooms = ((Number) q.get("rooms")).intValue();
        String ref = "BSR" + String.format("%08X", rnd.nextInt());

        boolean saved;
        synchronized (bookingLock) {                          // check and insert together: no double booking
            saved = Boolean.TRUE.equals(tx.execute(st -> {
                if (roomsLeft(hid, s) < rooms) return false;
                jdbc.update("INSERT INTO bookings(ref,user_id,hotel_id,check_in,check_out,guests,rooms,nights,total) VALUES(?,?,?,?,?,?,?,?,?)",
                    ref, user, hid, s.ci().toString(), s.co().toString(), s.guests(), rooms, q.get("nights"), q.get("total"));
                return true;
            }));
        }
        if (!saved) throw new ApiException(409, "Those dates just sold out. Try different dates.");

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("ref", ref); out.put("hotel", h.get("name")); out.put("city", h.get("city"));
        out.put("checkIn", s.ci().toString()); out.put("checkOut", s.co().toString()); out.put("guests", s.guests());
        out.putAll(q);
        return out;
    }

    @GetMapping("/bookings")
    public List<Map<String, Object>> bookings(@RequestHeader(value = "Authorization", required = false) String ah) {
        return jdbc.queryForList("""
            SELECT b.ref, b.hotel_id, b.check_in, b.check_out, b.guests, b.rooms, b.nights, b.total, b.status,
                   h.name AS hotel, h.city, h.scene
            FROM bookings b JOIN hotels h ON h.id=b.hotel_id
            WHERE b.user_id=? ORDER BY b.created_at DESC, b.id DESC""", uid(ah));
    }

    @DeleteMapping("/bookings/{ref}")
    public Map<String, Object> cancel(@RequestHeader(value = "Authorization", required = false) String ah, @PathVariable String ref) {
        int n = jdbc.update("UPDATE bookings SET status='cancelled' WHERE ref=? AND user_id=? AND status='confirmed'", ref, uid(ah));
        if (n == 0) throw new ApiException(404, "Booking not found.");
        return ok();
    }

    /* ---------- wishlist ---------- */
    @GetMapping("/wishlist")
    public List<Integer> wishlist(@RequestHeader(value = "Authorization", required = false) String ah) {
        return jdbc.queryForList("SELECT hotel_id FROM wishlist WHERE user_id=?", Integer.class, uid(ah));
    }

    @PutMapping("/wishlist/{id}")
    public Map<String, Object> save(@RequestHeader(value = "Authorization", required = false) String ah, @PathVariable long id) {
        long u = uid(ah); hotelRow(id);
        jdbc.update("INSERT OR IGNORE INTO wishlist(user_id,hotel_id) VALUES(?,?)", u, id);
        return ok();
    }

    @DeleteMapping("/wishlist/{id}")
    public Map<String, Object> unsave(@RequestHeader(value = "Authorization", required = false) String ah, @PathVariable long id) {
        jdbc.update("DELETE FROM wishlist WHERE user_id=? AND hotel_id=?", uid(ah), id);
        return ok();
    }
}
