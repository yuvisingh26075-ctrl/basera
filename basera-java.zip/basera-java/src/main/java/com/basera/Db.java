package com.basera;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/** Creates tables and seeds the 12 stays on first run. Replace the seed with your real inventory. */
@Component
public class Db implements CommandLineRunner {
    private final JdbcTemplate jdbc;
    private final ObjectMapper om;

    public Db(JdbcTemplate jdbc, ObjectMapper om) { this.jdbc = jdbc; this.om = om; }

    @Override
    public void run(String... args) throws Exception {
        jdbc.execute("""
            CREATE TABLE IF NOT EXISTS users(
              id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
              pass_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""");
        jdbc.execute("""
            CREATE TABLE IF NOT EXISTS hotels(
              id INTEGER PRIMARY KEY, name TEXT, city TEXT, type TEXT, price INTEGER, rating REAL,
              reviews INTEGER, scene TEXT, rooms INTEGER, amenities TEXT, description TEXT)""");
        jdbc.execute("""
            CREATE TABLE IF NOT EXISTS bookings(
              id INTEGER PRIMARY KEY, ref TEXT UNIQUE, user_id INTEGER NOT NULL REFERENCES users(id),
              hotel_id INTEGER NOT NULL REFERENCES hotels(id), check_in TEXT, check_out TEXT,
              guests INTEGER, rooms INTEGER, nights INTEGER, total INTEGER,
              status TEXT DEFAULT 'confirmed', created_at TEXT DEFAULT CURRENT_TIMESTAMP)""");
        jdbc.execute("CREATE INDEX IF NOT EXISTS idx_book_hotel ON bookings(hotel_id, status, check_in, check_out)");
        jdbc.execute("""
            CREATE TABLE IF NOT EXISTS wishlist(
              user_id INTEGER REFERENCES users(id), hotel_id INTEGER REFERENCES hotels(id),
              PRIMARY KEY(user_id, hotel_id))""");

        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM hotels", Integer.class);
        if (count != null && count > 0) return;

        Object[][] seed = {
            {"Sea Glass Resort","Goa","Resort",7800,4.6,1284,"beach",12,List.of("Pool","Beach access","Breakfast","Free Wi-Fi","Spa"),"Whitewashed rooms fifty steps from Palolem sands, with a pool bar and sunset yoga on the deck."},
            {"Deodar Ridge Cottage","Manali","Homestay",3200,4.8,642,"mountain",4,List.of("Mountain view","Bonfire","Home meals","Free parking"),"A wood-and-stone family home above Old Manali. Fresh apple pancakes arrive with the morning tea."},
            {"Haveli Surya Mahal","Jaipur","Hotel",5600,4.5,2210,"palace",20,List.of("Courtyard","Rooftop dining","Breakfast","AC","Free Wi-Fi"),"A restored 1890s haveli with painted arches, a quiet courtyard and a rooftop that faces Nahargarh Fort."},
            {"Lakeview Jharokha","Udaipur","Hotel",9400,4.9,1715,"lake",15,List.of("Lake view","Pool","Spa","Breakfast","AC"),"Every balcony looks over Lake Pichola and the City Palace. Request a room on the upper floor."},
            {"Tea Mist Villa","Munnar","Villa",11500,4.7,388,"forest",3,List.of("Private chef","Garden","Plantation walks","Free parking"),"A private three-bedroom villa among tea estates, with a chef who cooks Kerala fish curry on request."},
            {"Harbour Line Suites","Mumbai","Hotel",8900,4.3,3102,"city",40,List.of("Sea link view","Gym","Breakfast","Airport pickup","AC"),"Business-ready suites in Lower Parel, ten minutes from the sea link and a short walk to the metro."},
            {"Ganga Ghat Retreat","Rishikesh","Homestay",2400,4.6,905,"forest",8,List.of("Yoga hall","River view","Vegetarian meals","Free Wi-Fi"),"Wake to the river at dawn and join daily yoga. Rooms are simple, clean and quiet."},
            {"Pinewood Manor","Shimla","Villa",13800,4.8,274,"mountain",4,List.of("Fireplace","Valley view","Private chef","Free parking"),"A colonial-era manor with four bedrooms, wood fires and wide verandas above the Mall Road bustle."},
            {"Cinnamon Court","Delhi","Hotel",6200,4.2,2760,"city",30,List.of("Metro nearby","Gym","Breakfast","Free Wi-Fi","AC"),"Calm rooms in South Delhi near Hauz Khas, with quick access to the airport express line."},
            {"Havelock Shore Cabins","Andaman","Resort",12400,4.9,512,"beach",10,List.of("Beach access","Snorkelling","Breakfast","Spa"),"Stilted cabins on the Radhanagar side. Snorkel trips leave from the resort jetty each morning."},
            {"Rann Moon Camp","Jaipur","Resort",4700,4.4,731,"palace",14,List.of("Camel safari","Folk evenings","Dinner included","Free parking"),"Desert-style tents with real beds and warm bathrooms, plus folk music around the fire at night."},
            {"Dal Houseboat Noor","Srinagar","Homestay",3900,4.7,466,"lake",5,List.of("Lake view","Kashmiri meals","Shikara ride","Heater"),"Cedar-panelled houseboat on Dal Lake. Breakfast is served on the deck with noon chai."}
        };
        for (Object[] h : seed) {
            jdbc.update("INSERT INTO hotels(name,city,type,price,rating,reviews,scene,rooms,amenities,description) VALUES(?,?,?,?,?,?,?,?,?,?)",
                h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], om.writeValueAsString(h[8]), h[9]);
        }
    }
}
