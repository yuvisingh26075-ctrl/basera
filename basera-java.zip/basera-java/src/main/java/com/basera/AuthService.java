package com.basera;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {
    private final SecretKey key;
    private final Map<String, Deque<Long>> hits = new ConcurrentHashMap<>();

    public AuthService(@Value("${JWT_SECRET:}") String secret) {
        if (secret.length() < 32) {
            throw new IllegalStateException("Set JWT_SECRET to a random string of 32+ characters.");
        }
        key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String sign(long id, String name, String email) {
        return Jwts.builder().subject(String.valueOf(id)).claim("name", name).claim("email", email)
                .issuedAt(new Date()).expiration(new Date(System.currentTimeMillis() + 7L * 86_400_000))
                .signWith(key).compact();
    }

    public Claims verify(String header) {
        if (header == null || !header.startsWith("Bearer ")) throw new ApiException(401, "Please sign in again.");
        try {
            return Jwts.parser().verifyWith(key).build().parseSignedClaims(header.substring(7)).getPayload();
        } catch (JwtException | IllegalArgumentException e) {
            throw new ApiException(401, "Please sign in again.");
        }
    }

    /** 20 login/signup attempts per IP per 15 minutes. */
    public void limit(String ip) {
        long now = System.currentTimeMillis();
        Deque<Long> q = hits.computeIfAbsent(ip, k -> new ArrayDeque<>());
        synchronized (q) {
            while (!q.isEmpty() && now - q.peekFirst() > 900_000) q.pollFirst();
            if (q.size() >= 20) throw new ApiException(429, "Too many attempts. Try again in a few minutes.");
            q.addLast(now);
        }
    }
}
